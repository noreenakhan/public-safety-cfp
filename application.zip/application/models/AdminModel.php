<?php 

if (!defined('BASEPATH'))	exit('No direct script access allowed');

class AdminModel extends CI_Model
{
    
    public function district_add()
    {
        
    }
    
    public function districts_view()
    {
        
    }
    
    public function respondents_view()
    {
        
    }
    
    public function complaint_categories_view()
    {
        
    }
    
    public function complaint_category_add()
    {
        
    }
				
}

?>