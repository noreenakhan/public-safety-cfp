<?php 

if (!defined('BASEPATH'))	exit('No direct script access allowed');

class ComplaintModel extends CI_Model
{
    
    public function complaint_add()
    {
        
    }
    
    public function complaints_view()
    {
        
    }
    
    public function complaint_edit()
    {
        
    }
    
    //==========================================================================
    // remarks
    //==========================================================================
    
    public function complaint_remarks_view()
    {
        
    }
    
    public function complaint_remark_add()
    {
        
    }
				
}

?>