<!-- Main Content -->
<div class="main-content">
<section class="section">
<div class="row">
<div class="col-12 col-md-6 col-lg-3">
<div class="card card-primary hover">
<div class="card-header">
<h4 align="center">All Complaints</h4>
</div>
<div class="card-body">
<p> <code></code></p>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-3">
<div class="card card-primary">
<div class="card-header">
<h4 align="center">Pending </h4>
</div>
<div class="card-body">
<p><code></code></p>
</div>
</div>
</div>

<div class="col-12 col-md-6 col-lg-3">
<div class="card card-primary">
<div class="card-header">
<a href="Config_admin/sale_purchase"><h4 align="center">Completed</h4></a>
</div>
<div class="card-body">
<p><code></code></p>
</div>
</div>
</div>

<div class="col-12 col-md-6 col-lg-3">
<div class="card card-primary">
<div class="card-header">
<h4 align="center">Rejected</h4>
</div>
<div class="card-body">
<p> <code></code></p>
</div>
</div>
</div>

<div class="col-12 col-md-6 col-lg-3">
<div class="card card-primary">
<div class="card-header">
<h4 align="center">Complainants</h4>
</div>
<div class="card-body">
<p><code></code></p>
</div>
</div>
</div>
<div class="col-12 col-md-6 col-lg-3">
<div class="card card-primary">
<div class="card-header">
<h4 align="center">Complaints</h4>
</div>
<div class="card-body">
<p><code></code></p>
</div>
</div>
</div>
</div>
</section>
</div>
